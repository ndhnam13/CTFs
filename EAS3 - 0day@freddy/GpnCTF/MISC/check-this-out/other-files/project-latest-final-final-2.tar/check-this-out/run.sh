#!/usr/bin/env bash

echo "Well hello, friends :^)"
